package com.example.wingajob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
